/**********************************************************************
 *                                                  
 *  Guitar Hero: StringSound implementation and SFML audio output 
 **********************************************************************/

Name: Ambioris Lora

Hours to complete assignment : 18

/**********************************************************************
 *  Did you complete the whole assignment?
 *  Successfully or not? 
 *  Indicate which parts you think are working, and describe
 *    how you know that they're working.
 **********************************************************************/

Everything works "sometimes". I had someone play the instrument and it worked. I believe issue comes from the ringbuffer or the stringsound class but I could be wrong

/**********************************************************************
 *  Did you attempt the extra credit parts? Which one(s)?
 *  Successfully or not?  As a pair, or individually?
 **********************************************************************/
No extra credit


/**********************************************************************
 *  Did you implement exseptions to check your StringSound 
 *	implementation?
 *  Indicate yes or no, and explain how you did it.
 **********************************************************************/

No

/**********************************************************************
 *  List whatever help (if any) you received from TAs,
 *  classmates, or anyone else.
 **********************************************************************/

I asked one of my classmates to run my code to see if they got any segmentation fault on their computers and they said no.

/**********************************************************************
 *  Describe any serious problems you encountered.                    
 **********************************************************************/

I ran into alot of segmentation faults. Which were very hard to track. I asked someone to run my code to see if it was computer based which it seems to be. Im not sure whether this counts as not compiling. I understand if you cant give me agrade. I also dont know which type of computer this works on but if it doesnt compile i understand. 

/**********************************************************************
 *  List any other comments here.                                     
 **********************************************************************/

For some reason the test code doesnt work
