/************************************************************
* Linear FeedBack Shift Register(part a) readme.txt
************************************************************/

Name: Ambioris Lora
Hours to complete assignment: 8-10 hours
/****************************************************************
* Briefly discuss the assignment itself and what you accomplished 
****************************************************************/

The point of this assignment was to simulate LSFR using a binary string a tap position. In this scenario the tap positions were fixed. The LSFR takes the last bit and xors it with a given tap position then shifts it to the left and  replaces the first bit with the xor of the tap and shifted bit.

/****************************************************************
* Extra credit
****************************************************************/

N/a

/****************************************************************
* List whatever help you recieved
****************************************************************/

I noticed a mistake in the pdf which I double checked with professor Ryklova.

/****************************************************************
* Describe any serious problems you encountered
*****************************************************************/

I ran into multiple issues specifically with makefiles and test files. For some reason I couldnt use numbers as my LSFR in the test files.The makefile took a while to get to work. It did help to do research and it was a good learning experience.

/*****************************************************************
* List any other comments here. 
*****************************************************************/

Makefiles are useful but very confusing.
