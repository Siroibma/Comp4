/*************************************************************************
* Linear FeedBack Shift Register(Part B) ps1b-readme.txt
*************************************************************************/

Name: Ambioris Lora
OS: Windows
Machine: Hp Pavilion
Text Editior: emacs
Hours to Complete assignment: 4-5 hours

/************************************************************************
*Briefly discuss the assignemnt itself and what you accomplished 
************************************************************************/

The goal of the assignment was to use a LSFR to encode a picture into a bunch of random colors. Then we can use the same exact binary string to get the original picture. This created a pseudo password system that only works if you have the original binary string. I also accomplished this by xoring the the color values.


/************************************************************************
*List any extra credit you implemented
************************************************************************/

N/A

/***********************************************************************
* List whatever Help you recieved from teachers,ta or students
***********************************************************************/

I recieved no help

/***********************************************************************
* Describe any serious problems I had
***********************************************************************/

It was encoding any of pictures unless my variables were labeled x and y. This is the first time i have ever seen an error like that.


/***********************************************************************
* List any other comments
***********************************************************************/

I recommend mentioning how to use command line arguments.
